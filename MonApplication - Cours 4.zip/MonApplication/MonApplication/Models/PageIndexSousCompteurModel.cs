﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonApplication.Models
{
    public class PageIndexSousCompteurModel
    {
        public TypeOperateur Operateur { get; set; }
        public int NombreOperations { get; set; }
    }
}